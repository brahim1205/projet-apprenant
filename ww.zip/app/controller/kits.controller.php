<?php

function kits_index() {
    // Inclure la vue correspondante
    require_once APP_PATH . 'views/kits/kits.php';
}