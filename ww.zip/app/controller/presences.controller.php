<?php

function presences_index() {
    // Inclure la vue correspondante
    require_once APP_PATH . 'views/presences/presences.php';
}