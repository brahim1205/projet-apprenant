<?php

function rapports_index() {
    // Inclure la vue correspondante
    require_once APP_PATH . 'views/rapports/rapports.php';
}