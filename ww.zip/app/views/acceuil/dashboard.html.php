<!-- filepath: /home/khalil/Serveurphp/ges-apprenant/app/views/dashboard/dashboard.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord</title>
</head>
<body>
    <h1>Bienvenue sur le tableau de bord</h1>
    <p>Ceci est la page principale du tableau de bord.</p>
</body>
</html>