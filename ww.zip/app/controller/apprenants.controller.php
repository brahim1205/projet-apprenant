<?php

function apprenants_index() {
    // Inclure la vue correspondante
    require_once APP_PATH . 'views/apprenant/apprenant.php';
}